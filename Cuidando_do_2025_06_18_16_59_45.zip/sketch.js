let jogador;
let itensEcologicos = []; // Recicláveis, árvores, energia solar
let poluentes = []; // Fumaça, lixo não reciclável
let pontuacao = 0;
let nivelCO2 = 100; // Quanto maior, pior (game over se chegar a 200)
let gameOver = false;
let vitoria = false;
let tempoProximoItem = 0;
let tempoProximoPoluente = 0;

function setup() {
  createCanvas(800, 600);
  jogador = new Jogador();
}

function draw() {
  if (gameOver) {
    if (vitoria) {
      telaVitoria();
    } else {
      telaGameOver();
    }
    return;
  }

  desenharFundo();
  atualizarJogo();
  mostrarInformacoes();
}

function desenharFundo() {
  // Céu (gradiente azul -> vermelho conforme CO₂ aumenta)
  let corCeu = lerpColor(
    color(100, 200, 255),
    color(255, 100, 100),
    nivelCO2 / 200
  );
  background(corCeu);

  // Sol (fica mais avermelhado com poluição)
  fill(255, 255 - nivelCO2, 100);
  noStroke();
  ellipse(700, 100, 80, 80);

  // Terra (grama e poluição)
  fill(50, 200, 50);
  rect(0, 500, width, 100);

  // Barra de CO₂
  fill(0);
  rect(20, 20, 200, 30);
  fill(255, 100, 100, 150);
  rect(20, 20, map(nivelCO2, 0, 200, 0, 200), 30);
}

function atualizarJogo() {
  jogador.mostrar();
  jogador.atualizar();

  // Verifica condição de vitória
  if (nivelCO2 <= 5) {
    vitoria = true;
    gameOver = true;
    return;
  }

  // Gera itens ecológicos (recicláveis, árvores, energia solar)
  if (frameCount > tempoProximoItem) {
    itensEcologicos.push(new ItemEcologico());
    tempoProximoItem = frameCount + random(30, 90);
  }

  // Gera poluentes (fumaça, lixo não reciclável)
  if (frameCount > tempoProximoPoluente) {
    poluentes.push(new Poluente());
    tempoProximoPoluente = frameCount + random(60, 120);
  }

  // Atualiza itens ecológicos
  for (let i = itensEcologicos.length - 1; i >= 0; i--) {
    itensEcologicos[i].atualizar();
    itensEcologicos[i].mostrar();

    if (itensEcologicos[i].colidir(jogador)) {
      pontuacao += 10;
      nivelCO2 = max(0, nivelCO2 - 10); // Reduz CO₂ mais significativamente
      itensEcologicos.splice(i, 1);
    } else if (itensEcologicos[i].saiuDaTela()) {
      itensEcologicos.splice(i, 1);
    }
  }

  // Atualiza poluentes
  for (let i = poluentes.length - 1; i >= 0; i--) {
    poluentes[i].atualizar();
    poluentes[i].mostrar();

    if (poluentes[i].colidir(jogador)) {
      nivelCO2 += 15; // Aumenta CO₂
      poluentes.splice(i, 1);
      if (nivelCO2 >= 200) gameOver = true;
    } else if (poluentes[i].saiuDaTela()) {
      poluentes.splice(i, 1);
    }
  }

  // Aumenta CO₂ gradualmente (dificuldade)
  if (frameCount % 60 === 0) {
    nivelCO2 += 1;
    if (nivelCO2 >= 200) gameOver = true;
  }
}

function mostrarInformacoes() {
  fill(255);
  textSize(24);
  text(`Pontos: ${pontuacao}`, 20, 70);
  text(`CO₂: ${nivelCO2.toFixed(0)}/200`, 20, 100);
  fill("green");
  textSize(16);
  text(`Para iniciar o jogo clicar na tela`, 250, 30);
  text(`Para movimentar utilizar as setas`, 250, 50);


  if (nivelCO2 > 150) {
    fill(255, 0, 0);
    text("ALERTA: NÍVEL DE CO₂ MUITO ALTO!", width / 2 - 150, 80);
  } else if (nivelCO2 <= 20) {
    fill(0, 255, 0);
    text("ÓTIMO TRABALHO! CONTINUE ASSIM!", width / 2 - 150, 80);
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) jogador.mover(-50);
  if (keyCode === RIGHT_ARROW) jogador.mover(50);
  if (gameOver && key === " ") reiniciarJogo();
}

function reiniciarJogo() {
  itensEcologicos = [];
  poluentes = [];
  pontuacao = 0;
  nivelCO2 = 100;
  gameOver = false;
  vitoria = false;
  jogador = new Jogador();
  loop();
}

function telaVitoria() {
  background(" #2196F3"); // Fundo verde
  fill(255);
  textSize(60);
  textAlign(CENTER);
  text("Parabéns🥳!", width / 2, height / 2 - 80);
  text("Você Salvou o Planeta 🥰!", width / 2, height / 2 - 30);
  textSize(24);
  text(`CO₂ reduzido para ${nivelCO2.toFixed(0)}`, width / 2, height / 2 + 20);
  text(`Sua pontuação: ${pontuacao}`, width / 2, height / 2 + 60);
  text("Pressione ESPAÇO para jogar novamente", width / 2, height / 2 + 100);
}

function telaGameOver() {
  background(0);
  fill("red");
  textSize(60);
  textAlign(CENTER);
  text("GAME OVER", width / 2, height / 2 - 50);
  textSize(24);
  text(`O planeta atingiu níveis críticos de CO₂!`, width / 2, height / 2);
  text(`Sua pontuação: ${pontuacao}`, width / 2, height / 2 + 40);
  text("Pressione ESPAÇO para tentar novamente", width / 2, height / 2 + 80);
}

// CLASSES DO JOGO (permanecem iguais)
class Jogador {
  constructor() {
    this.x = width / 2;
    this.y = height - 100;
    this.largura = 60;
    this.altura = 80;
  }

  mostrar() {
    fill(0, 150, 255);
    rect(this.x - 30, this.y - 40, 60, 40);
    fill(255, 200, 150);
    ellipse(this.x, this.y - 50, 40, 40);
    fill(0);
    rect(this.x - 35, this.y, 15, 40);
    rect(this.x + 20, this.y, 15, 40);
  }

  atualizar() {
    this.x = constrain(this.x, this.largura / 2, width - this.largura / 2);
  }

  mover(velocidade) {
    this.x += velocidade;
  }
}

class ItemEcologico {
  constructor() {
    this.tipo = floor(random(3));
    this.x = random(50, width - 50);
    this.y = -50;
    this.velocidade = 3;
    this.tamanho = 40;
  }

  mostrar() {
    if (this.tipo === 0) {
      fill(0, 200, 255);
      rect(this.x - 15, this.y - 15, 30, 30, 5);
      fill(255);
      textSize(16);
      text("♻", this.x - 8, this.y + 5);
    } else if (this.tipo === 1) {
      fill(0, 150, 0);
      triangle(this.x, this.y - 30, this.x - 20, this.y, this.x + 20, this.y);
      fill(139, 69, 19);
      rect(this.x - 5, this.y, 10, 15);
    } else {
      fill(50, 50, 50);
      rect(this.x - 20, this.y - 10, 40, 5);
      fill(255, 255, 0);
      rect(this.x - 15, this.y - 15, 30, 5);
    }
  }

  atualizar() {
    this.y += this.velocidade;
  }

  colidir(jogador) {
    return (
      this.x > jogador.x - jogador.largura / 2 &&
      this.x < jogador.x + jogador.largura / 2 &&
      this.y > jogador.y - jogador.altura / 2 &&
      this.y < jogador.y + jogador.altura / 2
    );
  }

  saiuDaTela() {
    return this.y > height + 50;
  }
}

class Poluente {
  constructor() {
    this.tipo = floor(random(2));
    this.x = random(50, width - 50);
    this.y = -50;
    this.velocidade = 4;
    this.tamanho = 50;
  }

  mostrar() {
    if (this.tipo === 0) {
      fill(100, 100, 100, 150);
      ellipse(this.x, this.y, 40, 30);
      ellipse(this.x + 10, this.y - 10, 30, 20);
    } else {
      fill(150, 0, 0);
      rect(this.x - 15, this.y - 15, 30, 30);
      fill(255);
      textSize(20);
      text("☢", this.x - 10, this.y + 5);
    }
  }

  atualizar() {
    this.y += this.velocidade;
    if (this.tipo === 0) this.x += random(-2, 2);
  }

  colidir(jogador) {
    return (
      this.x > jogador.x - jogador.largura / 2 &&
      this.x < jogador.x + jogador.largura / 2 &&
      this.y > jogador.y - jogador.altura / 2 &&
      this.y < jogador.y + jogador.altura / 2
    );
  }

  saiuDaTela() {
    return this.y > height + 50;
  }
}